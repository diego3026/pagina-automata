try:
  import msz3 as z3
except:
  pass
