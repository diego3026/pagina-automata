import simplify
from core import Boolean,Number,Symbol,Wild,symbols,wilds,symbolic,wild,WildResults

import match
import solvers
